All games in this folder are freely available from:

http://www.harbaum.org/till/palm/mulg/games.html

As my Odrioid-Go Version of Mulg is not able to
show the author of a level and so on, please refer 
to the website above to obtain this information.

Thanks to Till Harbaum and all the great people
that made this game so cool and added so many levels!

Sep. 2019
Werner Mager